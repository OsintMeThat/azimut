This folder is an Azimut case.

  azimut/     Azimut's files.
  everything else here is yours.

Azimut does not read your folders, index them or clean them up. They travel
with the case when you export it.

Three things worth knowing:

  Do not move or rename anything inside azimut/ while Azimut is running.
  Do not name a folder "azimut" here. Windows would merge it with ours.
  Keep folder names short. A full path over 260 characters breaks on Windows.

To move this case, move the whole folder. To send it somewhere, export it
from Azimut instead of zipping this one: the export is checksummed, and it
can carry a password.
