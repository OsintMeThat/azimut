# Example case (fictional)

Saltmere, its storm of 14 and 15 March 2026 and every account here are invented, to show what Azimut holds once a case is filled. The photographs are real public-domain pictures of other storms and places, used as illustrations: each caption says where and when it was really taken, and each one's source, author and licence is in its Details.

Four notes, each made from a ready template of the Notebook:

- [[entity:e_83b420412f|The night the sea came into Saltmere]], a story for the web: Look › Web page is set to Story.
- [[entity:e_fe2b2bf845|Boats lost at Saltmere, the register]]: a register, its infographic, a chart and a picture wall.
- [[entity:e_6cc4245aae|Were the houses flattened? Three claims against the pictures]]: claims set against proofs.
- [[entity:e_2a2905bbfd|Damage on Beach Road, an assessment]]: a brief with a before and after.

- [ ] Open a note and press Page, then HTML
- [ ] Export the story as a web folder
