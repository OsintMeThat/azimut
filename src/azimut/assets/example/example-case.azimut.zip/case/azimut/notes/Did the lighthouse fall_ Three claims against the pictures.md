> [!note] Fictional example. Saltmere, its storm of 14 and 15 March 2026 and every account quoted here are invented, to show what a note can hold. The photographs are real, public-domain pictures of other storms and places, each credited under it.

> [!warning] Two of the three claims are false and the third overstates: the lighthouse stands, the launch is ashore, and at least 16 boats were lost, not fifty.

## The claims

| # | Claim | Made by | Day | Verdict |
| --- | --- | --- | --- | --- |
| 1 | "The lighthouse at Cape Hallow has fallen" | [[entity:e_7c66fd1fa7|@saltmere_breaking]] | 15 Mar 2026 | False |
| 2 | "The island launch sank in the harbour" | [[entity:e_7c66fd1fa7|@saltmere_breaking]] | 15 Mar 2026 | False |
| 3 | "Fifty boats destroyed at Saltmere" | [[entity:e_7c66fd1fa7|@saltmere_breaking]] | 16 Mar 2026 | Misleading |
{search=always colour="Verdict"}

## Claims and pictures, day by day

::: chart
kind: timeline
title: Each claim, then what the pictures show
colour by: Kind
labels: short
source: posts of 15 and 16 March and the proofs of this case
| When | What happened | Kind |
| --- | --- | --- |
| 15 Mar 2026 | "The lighthouse at Cape Hallow has fallen" | Claim |
| 15 Mar 2026 | The old pier lost its end and the light on it | Geolocated |
| 15 Mar 2026 | "The island launch sank in the harbour" | Claim |
| 15 Mar 2026 | The launch lies upright on the beach | Geolocated |
| 16 Mar 2026 | "Fifty boats destroyed at Saltmere" | Claim |
| 16 Mar 2026 | The lighthouse stands, water round its foot | Geolocated |
:::

## How the first claim spread

```mermaid
%% legend c1: Claim
%% legend c2: What the pictures show
flowchart LR
  A["@saltmere_breaking: the lighthouse has fallen"]:::c1 --> B["Reposted, no picture"]:::c1
  B --> C["The old pier's light is down"]:::c2
  C --> D["The lighthouse stands"]:::c2
  classDef c1 fill:#fbe3d6,stroke:#d55e00,color:#5a2400
  classDef c2 fill:#d9f0e6,stroke:#009e73,color:#00422f
```

## Claim 1: the lighthouse

> "The lighthouse at Cape Hallow has fallen." ([[entity:e_3dcd1a7b8b|@saltmere_breaking, 15 Mar]])

The post came with no picture. Pictures of the old pier taken the same morning show its deck gone beyond the surf line, and with it the small light at its end ([[entity:e_38274142ac|proof]]). The lighthouse at Cape Hallow is another structure, 2 km to the south-east, and on 16 March it stood whole ([[entity:e_c7ce71bbb0|proof]]).

[[media:e_38274142ac|The old pier lost its end]]{width=75% caption="The old pier on 15 March. Photo: Marvin Nauman, FEMA (Grand Isle, Louisiana, 2005), public domain."}

> [!warning] False. What fell was the light on the old pier, not the lighthouse.

## Claim 2: the launch

> "The island launch sank in the harbour." ([[entity:e_9eba718660|@saltmere_breaking, 15 Mar]])

[[media:e_8ff9d4ea71|The launch is ashore, not sunk]]{width=75% caption="The launch on the beach on 15 March. Photo: Jocelyn Augustino, FEMA (Pensacola Beach, Florida, 2005), public domain."}

> [!warning] False. The launch lies upright on the beach west of the old pier, above the tide line.

## Claim 3: fifty boats

> "Fifty boats destroyed at Saltmere." ([[entity:e_a32873d69b|@saltmere_breaking, 16 Mar]])

The register counts at least 16 boats lost or damaged, 2 of them sunk ([[entity:e_dd18fcea80|the register]]). Fifty is more than the marina held.

> [!unverified] Misleading. At least 16 boats, of which 11 were carried ashore and 2 sank.

## Corrections

17 March 2026: the first edition counted at least 15 boats. The drone flight of 16 March found a sixteenth in the salt marsh, and the count now reads at least 16.
