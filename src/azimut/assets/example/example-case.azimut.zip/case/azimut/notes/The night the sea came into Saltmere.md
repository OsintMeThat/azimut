> [!note] Fictional example. Saltmere, its storm of 14 and 15 March 2026 and every account quoted here are invented, to show what a note can hold. The photographs are real, public-domain pictures of other storms and places, each credited under it.

[[media:e_eacec0c533|Yachts thrown onto the marina quay]]{width=100% caption="The marina quay on the morning of 15 March. Photo: Walter Jennings, FEMA (Bayland Marina, Texas, 2008), public domain."}

The storm reached Saltmere a little after ten at night on 14 March. By first light the marina was a yard of hulls on their sides, Beach Road lay under sand, and a post going round said the lighthouse had fallen. **At least 16 boats were lost or damaged, 2 of them sunk. The lighthouse still stands.**

Every figure here is a minimum: it counts only what the pictures show.

## The marina at first light

[[media:e_cc54f24ca7|The marina canal on 15 March]]{width=100% caption="The marina canal on 15 March. Photo: Liz Roll, FEMA (Port Arthur, Texas, 2008), public domain."}

The surge lifted boats off their moorings and set them down on the bank, some still on their cradles. One yacht stayed afloat in the canal, its deck full of the reeds the water left behind.

[[media:e_19c921ff38|A yacht carried into the salt marsh]]{width=100% caption="A yacht carried into the salt marsh east of the marina, seen from the drone flight of 16 March. Photo: Jessica Potter, U.S. Coast Guard (North Carolina, 2011), public domain."}

The water carried one yacht across the road and into the salt marsh, where the drone flight of 16 March found it upright in the grass.

## Beach Road, before and after

[[media:e_18d218b1c0|Beach Road before and after the storm]]{width=100% caption="Beach Road on 2 March and on 16 March. NOAA aerial photographs (Mexico Beach, Florida, 2017 and 2018), public domain."}

From the air, two weeks apart: the road is gone under sand, and most of the houses between it and the beach have lost their roofs or their walls.

## Where everything lies

::: map
title: Saltmere, 14 to 16 March 2026
layer: Boats lost
layer: Storm damage
ground: e_b8221ddf66
north: on
legend: shown
step: 2026-03-15 | The morning after | -41.199568, -22.601330, 15.6 | | The marina, Beach Road and the beach at first light.
step: 2026-03-15 | The marina at first light | -41.198575, -22.600772, 16.4 | | The surge left boats on the bank round the marina basin and flooded the low streets.
step: 2026-03-15 | Beach Road under sand | -41.199568, -22.601330, 16.2 | | Sand covers the road its whole length.
step: 2026-03-15 | The old pier and the launch | -41.200400, -22.600837, 16.4 | e_93b2f9ce71 | The pier lost its end; the launch lies upright on the beach.
step: 2026-03-16 | Every boat counted | -41.199568, -22.601330, 15.6 | | Sixteen boats, each where the pictures put it, coloured by how sure the count is.
:::

Each step is a day and a place: the marina, the road, the beach, then every boat of the register where it lies.

## Every boat, one frame each

::: chart
kind: pictures
title: At least 16 boats, one frame each, by type
by: Type
colour by: Grade
order: Confirmed, Almost sure, Strong doubt
picture: Picture
label: #
words: Status
story: one group per step
source: frames from the marina survey, the harbour and beach walks and the drone flight of 15 and 16 March
| Picture | # | Status | Type | Grade |
| --- | --- | --- | --- | --- |
| [[media:e_98d82e3a46|#1]] | #1 | Ashore | Motor cruiser | Confirmed |
| [[media:e_a4df958ea0|#2]] | #2 | Ashore | Sailing yacht | Confirmed |
| [[media:e_d1c26eff8f|#3]] | #3 | Ashore | Sailing yacht | Almost sure |
| [[media:e_21d457d588|#4]] | #4 | Damaged | Sailing yacht | Confirmed |
| [[media:e_cb8d54cba1|#5]] | #5 | Ashore | Motor cruiser | Almost sure |
| [[media:e_8bda8be652|#6]] | #6 | Ashore | Motor cruiser | Confirmed |
| [[media:e_ec46a462f5|#7]] | #7 | Damaged | Sailing yacht | Confirmed |
| [[media:e_b9eb550d03|#8]] | #8 | Ashore | Sport fisher | Confirmed |
| [[media:e_dbd3fd112f|#9]] | #9 | Ashore | Motor cruiser | Strong doubt |
| [[media:e_59fe843802|#10]] | #10 | Ashore | Runabout | Confirmed |
| [[media:e_062dee52d0|#11]] | #11 | Sunk | Sailing yacht | Confirmed |
| [[media:e_6079308273|#12]] | #12 | Ashore | Sailing yacht | Almost sure |
| [[media:e_d428ef5010|#13]] | #13 | Ashore | Motor cruiser | Confirmed |
| [[media:e_747e8d79d8|#14]] | #14 | Capsized | Shrimp boat | Confirmed |
| [[media:e_0cef8d3b07|#15]] | #15 | Ashore | Sailing yacht | Almost sure |
| [[media:e_30b8169a1c|#16]] | #16 | Ashore | Runabout | Strong doubt |
:::

Each boat is counted once, across every picture. The grade says how sure its type is, not how badly it was hit.

## What was said, and what the pictures show

::: chart
kind: timeline
title: What was said, and what the pictures show
colour by: Kind
source: posts of 14 to 18 March and the proofs of this case
| When | What happened | Kind |
| --- | --- | --- |
| 14 Mar 2026 | The marina closes ahead of the storm | Press |
| 15 Mar 2026 | "The lighthouse has fallen" | Claim |
| 15 Mar 2026 | The old pier has lost its end | Geolocated |
| 15 Mar 2026 | "The launch sank in the harbour" | Claim |
| 15 Mar 2026 | The launch lies ashore, upright | Geolocated |
| 16 Mar 2026 | "Fifty boats destroyed" | Claim |
| 16 Mar 2026 | The lighthouse stands | Geolocated |
| 18 Mar 2026 | The marina reopens to the launch | Press |
:::

## What fell, and what did not

[[media:e_99d757c182|Cape Hallow lighthouse stands]]{width=50% caption="Cape Hallow lighthouse on 16 March. Photo: David A. Weydert, U.S. Coast Guard (Bodie Island, North Carolina, 2011), public domain."}

The post that said the lighthouse had fallen ([[entity:e_94f963a1b8|@saltmere_breaking, 15 Mar]]) came with no picture. The next morning the lighthouse stood whole, water round its foot ([[entity:e_99d757c182|proof]]). What fell was the light at the end of the old pier, whose deck the sea took ([[entity:e_93b2f9ce71|proof]]).

> [!limits] The pictures cover the marina, Beach Road and the beach. Nothing here says what the storm did inland, or to anyone.
