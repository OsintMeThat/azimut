> [!note] Fictional example. Saltmere, its storm of 14 and 15 March 2026 and every account quoted here are invented, to show what a note can hold. The photographs are real, public-domain pictures of other storms and places, each credited in the case.

> [!note] Every count is a minimum: each boat is counted once, across the marina survey, two walks and the drone flight of 15 and 16 March.

## At a glance

:::: infographic
data: sheet:e_e19149ab5e
title: Boats lost at Saltmere, at a glance
look: report
widths: wide, half, half, wide

::: chart
kind: key figures
source: the boat register, a sheet of this case
rows: own
| Figure | What it says |
| --- | --- |
| at least 16 | boats lost or damaged in the marina and on the beach |
| 11 | carried ashore off their moorings |
| at least 2 | sunk where they lay |
:::

::: chart
kind: pictograms
source: the boat register, a sheet of this case
title: At least 16 boats, by how sure the type is
count: rows
by: Grade
order: Confirmed, Almost sure, Strong doubt
| # | Type | Status | Grade | Seen in | First seen | Coordinates |
| --- | --- | --- | --- | --- | --- | --- |
| #1 | Motor cruiser | Ashore | Confirmed | Marina survey | 15 Mar 2026 | -41.198398, -22.601749 |
| #2 | Sailing yacht | Ashore | Confirmed | Marina survey | 15 Mar 2026 | -41.198511, -22.601513 |
| #3 | Sailing yacht | Ashore | Almost sure | Marina survey | 15 Mar 2026 | -41.198333, -22.601266 |
| #4 | Sailing yacht | Damaged | Confirmed | Marina survey | 15 Mar 2026 | -41.198720, -22.600654 |
| #5 | Motor cruiser | Ashore | Almost sure | Marina survey | 15 Mar 2026 | -41.197558, -22.602693 |
| #6 | Motor cruiser | Ashore | Confirmed | Marina survey | 15 Mar 2026 | -41.197639, -22.602393 |
| #7 | Sailing yacht | Damaged | Confirmed | Marina survey | 15 Mar 2026 | -41.198914, -22.600333 |
| #8 | Sport fisher | Ashore | Confirmed | Harbour walk | 15 Mar 2026 | -41.197816, -22.603358 |
| #9 | Motor cruiser | Ashore | Strong doubt | Harbour walk | 15 Mar 2026 | -41.198026, -22.603090 |
| #10 | Runabout | Ashore | Confirmed | Harbour walk | 15 Mar 2026 | -41.199269, -22.598337 |
| #11 | Sailing yacht | Sunk | Confirmed | Harbour walk | 16 Mar 2026 | -41.198914, -22.600976 |
| #12 | Sailing yacht | Ashore | Almost sure | Harbour walk | 16 Mar 2026 | -41.198188, -22.603937 |
| #13 | Motor cruiser | Ashore | Confirmed | Beach walk | 15 Mar 2026 | -41.201223, -22.599238 |
| #14 | Shrimp boat | Capsized | Confirmed | Drone flight | 16 Mar 2026 | -41.197090, -22.604324 |
| #15 | Sailing yacht | Ashore | Almost sure | Drone flight | 16 Mar 2026 | -41.198301, -22.596599 |
| #16 | Runabout | Ashore | Strong doubt | Drone flight | 16 Mar 2026 | -41.197897, -22.597457 |
:::

::: chart
kind: donut
source: the boat register, a sheet of this case
title: At least 16 boats, by what became of them
count: rows
by: Status
| # | Type | Status | Grade | Seen in | First seen | Coordinates |
| --- | --- | --- | --- | --- | --- | --- |
| #1 | Motor cruiser | Ashore | Confirmed | Marina survey | 15 Mar 2026 | -41.198398, -22.601749 |
| #2 | Sailing yacht | Ashore | Confirmed | Marina survey | 15 Mar 2026 | -41.198511, -22.601513 |
| #3 | Sailing yacht | Ashore | Almost sure | Marina survey | 15 Mar 2026 | -41.198333, -22.601266 |
| #4 | Sailing yacht | Damaged | Confirmed | Marina survey | 15 Mar 2026 | -41.198720, -22.600654 |
| #5 | Motor cruiser | Ashore | Almost sure | Marina survey | 15 Mar 2026 | -41.197558, -22.602693 |
| #6 | Motor cruiser | Ashore | Confirmed | Marina survey | 15 Mar 2026 | -41.197639, -22.602393 |
| #7 | Sailing yacht | Damaged | Confirmed | Marina survey | 15 Mar 2026 | -41.198914, -22.600333 |
| #8 | Sport fisher | Ashore | Confirmed | Harbour walk | 15 Mar 2026 | -41.197816, -22.603358 |
| #9 | Motor cruiser | Ashore | Strong doubt | Harbour walk | 15 Mar 2026 | -41.198026, -22.603090 |
| #10 | Runabout | Ashore | Confirmed | Harbour walk | 15 Mar 2026 | -41.199269, -22.598337 |
| #11 | Sailing yacht | Sunk | Confirmed | Harbour walk | 16 Mar 2026 | -41.198914, -22.600976 |
| #12 | Sailing yacht | Ashore | Almost sure | Harbour walk | 16 Mar 2026 | -41.198188, -22.603937 |
| #13 | Motor cruiser | Ashore | Confirmed | Beach walk | 15 Mar 2026 | -41.201223, -22.599238 |
| #14 | Shrimp boat | Capsized | Confirmed | Drone flight | 16 Mar 2026 | -41.197090, -22.604324 |
| #15 | Sailing yacht | Ashore | Almost sure | Drone flight | 16 Mar 2026 | -41.198301, -22.596599 |
| #16 | Runabout | Ashore | Strong doubt | Drone flight | 16 Mar 2026 | -41.197897, -22.597457 |
:::

::: chart
kind: bars
source: the boat register, a sheet of this case
title: At least 16 boats, by type
count: rows
by: Type
| # | Type | Status | Grade | Seen in | First seen | Coordinates |
| --- | --- | --- | --- | --- | --- | --- |
| #1 | Motor cruiser | Ashore | Confirmed | Marina survey | 15 Mar 2026 | -41.198398, -22.601749 |
| #2 | Sailing yacht | Ashore | Confirmed | Marina survey | 15 Mar 2026 | -41.198511, -22.601513 |
| #3 | Sailing yacht | Ashore | Almost sure | Marina survey | 15 Mar 2026 | -41.198333, -22.601266 |
| #4 | Sailing yacht | Damaged | Confirmed | Marina survey | 15 Mar 2026 | -41.198720, -22.600654 |
| #5 | Motor cruiser | Ashore | Almost sure | Marina survey | 15 Mar 2026 | -41.197558, -22.602693 |
| #6 | Motor cruiser | Ashore | Confirmed | Marina survey | 15 Mar 2026 | -41.197639, -22.602393 |
| #7 | Sailing yacht | Damaged | Confirmed | Marina survey | 15 Mar 2026 | -41.198914, -22.600333 |
| #8 | Sport fisher | Ashore | Confirmed | Harbour walk | 15 Mar 2026 | -41.197816, -22.603358 |
| #9 | Motor cruiser | Ashore | Strong doubt | Harbour walk | 15 Mar 2026 | -41.198026, -22.603090 |
| #10 | Runabout | Ashore | Confirmed | Harbour walk | 15 Mar 2026 | -41.199269, -22.598337 |
| #11 | Sailing yacht | Sunk | Confirmed | Harbour walk | 16 Mar 2026 | -41.198914, -22.600976 |
| #12 | Sailing yacht | Ashore | Almost sure | Harbour walk | 16 Mar 2026 | -41.198188, -22.603937 |
| #13 | Motor cruiser | Ashore | Confirmed | Beach walk | 15 Mar 2026 | -41.201223, -22.599238 |
| #14 | Shrimp boat | Capsized | Confirmed | Drone flight | 16 Mar 2026 | -41.197090, -22.604324 |
| #15 | Sailing yacht | Ashore | Almost sure | Drone flight | 16 Mar 2026 | -41.198301, -22.596599 |
| #16 | Runabout | Ashore | Strong doubt | Drone flight | 16 Mar 2026 | -41.197897, -22.597457 |
:::
::::

## Register

| # | Picture | Type | Status | Grade | Seen in | First seen |
| --- | --- | --- | --- | --- | --- | --- |
| #1 | [[media:e_89d0ad503e|#1]] | Motor cruiser | Ashore | Confirmed | Marina survey | 15 Mar 2026 |
| #2 | [[media:e_32fd448065|#2]] | Sailing yacht | Ashore | Confirmed | Marina survey | 15 Mar 2026 |
| #3 | [[media:e_6b206500ad|#3]] | Sailing yacht | Ashore | Almost sure | Marina survey | 15 Mar 2026 |
| #4 | [[media:e_a49cd4b942|#4]] | Sailing yacht | Damaged | Confirmed | Marina survey | 15 Mar 2026 |
| #5 | [[media:e_04d8b42c22|#5]] | Motor cruiser | Ashore | Almost sure | Marina survey | 15 Mar 2026 |
| #6 | [[media:e_5be2c53c12|#6]] | Motor cruiser | Ashore | Confirmed | Marina survey | 15 Mar 2026 |
| #7 | [[media:e_286859a1c0|#7]] | Sailing yacht | Damaged | Confirmed | Marina survey | 15 Mar 2026 |
| #8 | [[media:e_5df7fac088|#8]] | Sport fisher | Ashore | Confirmed | Harbour walk | 15 Mar 2026 |
| #9 | [[media:e_f40c37d4ee|#9]] | Motor cruiser | Ashore | Strong doubt | Harbour walk | 15 Mar 2026 |
| #10 | [[media:e_ea732f7b9b|#10]] | Runabout | Ashore | Confirmed | Harbour walk | 15 Mar 2026 |
| #11 | [[media:e_823db6e791|#11]] | Sailing yacht | Sunk | Confirmed | Harbour walk | 16 Mar 2026 |
| #12 | [[media:e_27e0c16a67|#12]] | Sailing yacht | Ashore | Almost sure | Harbour walk | 16 Mar 2026 |
| #13 | [[media:e_4a1e507f99|#13]] | Motor cruiser | Ashore | Confirmed | Beach walk | 15 Mar 2026 |
| #14 | [[media:e_76671cb2ee|#14]] | Shrimp boat | Capsized | Confirmed | Drone flight | 16 Mar 2026 |
| #15 | [[media:e_bce26074f7|#15]] | Sailing yacht | Ashore | Almost sure | Drone flight | 16 Mar 2026 |
| #16 | [[media:e_91aa3fe45e|#16]] | Runabout | Ashore | Strong doubt | Drone flight | 16 Mar 2026 |
{search=always fold=20 first-column stripes colour="Grade" density=compact caption="Every boat the pictures show, once" source="Marina survey, harbour and beach walks, drone flight"}

One row per boat, from the case's sheet [[entity:e_e19149ab5e|Boat register]]. The grade says how sure its type is, not how badly it was hit.

## By type

::: chart
kind: stacked bars
title: At least 16 boats, by type and grade
count: rows
by: Type
colour by: Grade
order: Confirmed, Almost sure, Strong doubt
from: sheet:e_e19149ab5e
source: the boat register
| Type | Grade |
| --- | --- |
| Motor cruiser | Confirmed |
| Sailing yacht | Confirmed |
| Sailing yacht | Almost sure |
| Sailing yacht | Confirmed |
| Motor cruiser | Almost sure |
| Motor cruiser | Confirmed |
| Sailing yacht | Confirmed |
| Sport fisher | Confirmed |
| Motor cruiser | Strong doubt |
| Runabout | Confirmed |
| Sailing yacht | Confirmed |
| Sailing yacht | Almost sure |
| Motor cruiser | Confirmed |
| Shrimp boat | Confirmed |
| Sailing yacht | Almost sure |
| Runabout | Strong doubt |
:::

## Every boat, one frame each

::: chart
kind: pictures
title: At least 16 boats, one frame each, by what became of them
by: Status
colour by: Grade
order: Confirmed, Almost sure, Strong doubt
picture: Picture
label: #
words: Type
shape: 3:2
source: frames from the marina survey, the harbour and beach walks and the drone flight
| Picture | # | Type | Status | Grade |
| --- | --- | --- | --- | --- |
| [[media:e_89d0ad503e|#1]] | #1 | Motor cruiser | Ashore | Confirmed |
| [[media:e_32fd448065|#2]] | #2 | Sailing yacht | Ashore | Confirmed |
| [[media:e_6b206500ad|#3]] | #3 | Sailing yacht | Ashore | Almost sure |
| [[media:e_a49cd4b942|#4]] | #4 | Sailing yacht | Damaged | Confirmed |
| [[media:e_04d8b42c22|#5]] | #5 | Motor cruiser | Ashore | Almost sure |
| [[media:e_5be2c53c12|#6]] | #6 | Motor cruiser | Ashore | Confirmed |
| [[media:e_286859a1c0|#7]] | #7 | Sailing yacht | Damaged | Confirmed |
| [[media:e_5df7fac088|#8]] | #8 | Sport fisher | Ashore | Confirmed |
| [[media:e_f40c37d4ee|#9]] | #9 | Motor cruiser | Ashore | Strong doubt |
| [[media:e_ea732f7b9b|#10]] | #10 | Runabout | Ashore | Confirmed |
| [[media:e_823db6e791|#11]] | #11 | Sailing yacht | Sunk | Confirmed |
| [[media:e_27e0c16a67|#12]] | #12 | Sailing yacht | Ashore | Almost sure |
| [[media:e_4a1e507f99|#13]] | #13 | Motor cruiser | Ashore | Confirmed |
| [[media:e_76671cb2ee|#14]] | #14 | Shrimp boat | Capsized | Confirmed |
| [[media:e_bce26074f7|#15]] | #15 | Sailing yacht | Ashore | Almost sure |
| [[media:e_91aa3fe45e|#16]] | #16 | Runabout | Ashore | Strong doubt |
:::

## Where they lie

::: map
title: Where each boat lies
layer: Boats lost
ground: e_7eb1986c34
timeline: off
north: on
:::

The register is a sheet of the case with a column of coordinates, so the map takes it as a layer coloured by grade, and follows the sheet when it changes.

> [!limits] Boats sunk out of sight in the canal, and those the pictures saw only from far off, are not counted. The true number is higher.
