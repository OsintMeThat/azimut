> [!note] Fictional example. Saltmere, its storm of 14 and 15 March 2026 and every account quoted here are invented, to show what a note can hold. The photographs are real public-domain pictures of other storms and places, used as illustrations: each caption says where and when it was really taken.

> [!note] Every count is a minimum: each boat is counted once, across the marina survey, two walks and the drone flight of 15 and 16 March.

Each boat the pictures show lost, sunk or damaged by the storm of 14 and 15 March has one row in the register, its type, what became of it and how sure its type is. The count stops on 16 March, with the drone flight.

The register is the case's sheet [[entity:e_1c3e0b3f71|Boat register]]: the infographic, the chart and the map below all read it, and say so when it changes.

## At a glance

:::: infographic
data: sheet:e_1c3e0b3f71
title: Boats lost at Saltmere, at a glance
look: report
widths: wide, half, half, wide

::: chart
kind: key figures
source: the boat register, a sheet of this case
rows: own
| Figure | What it says |
| --- | --- |
| at least 16 | boats lost or damaged in the marina and on the beach |
| 11 | carried ashore off their moorings |
| at least 2 | sunk where they lay |
:::

::: chart
kind: pictograms
source: the boat register, a sheet of this case
title: At least 16 boats, by how sure the type is
count: rows
by: Grade
order: Confirmed, Almost sure, Strong doubt
| # | Type | Status | Grade | Seen in | First seen | Coordinates |
| --- | --- | --- | --- | --- | --- | --- |
| #1 | Motor cruiser | Ashore | Confirmed | Marina survey | 15 Mar 2026 | -41.199544, -22.602929 |
| #2 | Sailing yacht | Ashore | Confirmed | Marina survey | 15 Mar 2026 | -41.199318, -22.602285 |
| #3 | Sailing yacht | Ashore | Almost sure | Marina survey | 15 Mar 2026 | -41.199156, -22.601749 |
| #4 | Sailing yacht | Damaged | Confirmed | Marina survey | 15 Mar 2026 | -41.199528, -22.601298 |
| #5 | Motor cruiser | Ashore | Almost sure | Marina survey | 15 Mar 2026 | -41.199221, -22.600590 |
| #6 | Motor cruiser | Ashore | Confirmed | Marina survey | 15 Mar 2026 | -41.199576, -22.599925 |
| #7 | Sailing yacht | Damaged | Confirmed | Marina survey | 15 Mar 2026 | -41.199156, -22.599367 |
| #8 | Sport fisher | Ashore | Confirmed | Harbour walk | 15 Mar 2026 | -41.199027, -22.598637 |
| #9 | Motor cruiser | Ashore | Strong doubt | Harbour walk | 15 Mar 2026 | -41.198575, -22.598294 |
| #10 | Runabout | Ashore | Confirmed | Harbour walk | 15 Mar 2026 | -41.198817, -22.597586 |
| #11 | Sailing yacht | Sunk | Confirmed | Harbour walk | 16 Mar 2026 | -41.199625, -22.603573 |
| #12 | Sailing yacht | Ashore | Almost sure | Harbour walk | 16 Mar 2026 | -41.200690, -22.602156 |
| #13 | Motor cruiser | Ashore | Confirmed | Beach walk | 15 Mar 2026 | -41.202143, -22.601427 |
| #14 | Shrimp boat | Capsized | Confirmed | Drone flight | 16 Mar 2026 | -41.199948, -22.604216 |
| #15 | Sailing yacht | Ashore | Almost sure | Drone flight | 16 Mar 2026 | -41.199786, -22.602285 |
| #16 | Runabout | Ashore | Strong doubt | Drone flight | 16 Mar 2026 | -41.198462, -22.597457 |
:::

::: chart
kind: donut
source: the boat register, a sheet of this case
title: At least 16 boats, by what became of them
count: rows
by: Status
| # | Type | Status | Grade | Seen in | First seen | Coordinates |
| --- | --- | --- | --- | --- | --- | --- |
| #1 | Motor cruiser | Ashore | Confirmed | Marina survey | 15 Mar 2026 | -41.199544, -22.602929 |
| #2 | Sailing yacht | Ashore | Confirmed | Marina survey | 15 Mar 2026 | -41.199318, -22.602285 |
| #3 | Sailing yacht | Ashore | Almost sure | Marina survey | 15 Mar 2026 | -41.199156, -22.601749 |
| #4 | Sailing yacht | Damaged | Confirmed | Marina survey | 15 Mar 2026 | -41.199528, -22.601298 |
| #5 | Motor cruiser | Ashore | Almost sure | Marina survey | 15 Mar 2026 | -41.199221, -22.600590 |
| #6 | Motor cruiser | Ashore | Confirmed | Marina survey | 15 Mar 2026 | -41.199576, -22.599925 |
| #7 | Sailing yacht | Damaged | Confirmed | Marina survey | 15 Mar 2026 | -41.199156, -22.599367 |
| #8 | Sport fisher | Ashore | Confirmed | Harbour walk | 15 Mar 2026 | -41.199027, -22.598637 |
| #9 | Motor cruiser | Ashore | Strong doubt | Harbour walk | 15 Mar 2026 | -41.198575, -22.598294 |
| #10 | Runabout | Ashore | Confirmed | Harbour walk | 15 Mar 2026 | -41.198817, -22.597586 |
| #11 | Sailing yacht | Sunk | Confirmed | Harbour walk | 16 Mar 2026 | -41.199625, -22.603573 |
| #12 | Sailing yacht | Ashore | Almost sure | Harbour walk | 16 Mar 2026 | -41.200690, -22.602156 |
| #13 | Motor cruiser | Ashore | Confirmed | Beach walk | 15 Mar 2026 | -41.202143, -22.601427 |
| #14 | Shrimp boat | Capsized | Confirmed | Drone flight | 16 Mar 2026 | -41.199948, -22.604216 |
| #15 | Sailing yacht | Ashore | Almost sure | Drone flight | 16 Mar 2026 | -41.199786, -22.602285 |
| #16 | Runabout | Ashore | Strong doubt | Drone flight | 16 Mar 2026 | -41.198462, -22.597457 |
:::

::: chart
kind: bars
source: the boat register, a sheet of this case
title: At least 16 boats, by type
count: rows
by: Type
| # | Type | Status | Grade | Seen in | First seen | Coordinates |
| --- | --- | --- | --- | --- | --- | --- |
| #1 | Motor cruiser | Ashore | Confirmed | Marina survey | 15 Mar 2026 | -41.199544, -22.602929 |
| #2 | Sailing yacht | Ashore | Confirmed | Marina survey | 15 Mar 2026 | -41.199318, -22.602285 |
| #3 | Sailing yacht | Ashore | Almost sure | Marina survey | 15 Mar 2026 | -41.199156, -22.601749 |
| #4 | Sailing yacht | Damaged | Confirmed | Marina survey | 15 Mar 2026 | -41.199528, -22.601298 |
| #5 | Motor cruiser | Ashore | Almost sure | Marina survey | 15 Mar 2026 | -41.199221, -22.600590 |
| #6 | Motor cruiser | Ashore | Confirmed | Marina survey | 15 Mar 2026 | -41.199576, -22.599925 |
| #7 | Sailing yacht | Damaged | Confirmed | Marina survey | 15 Mar 2026 | -41.199156, -22.599367 |
| #8 | Sport fisher | Ashore | Confirmed | Harbour walk | 15 Mar 2026 | -41.199027, -22.598637 |
| #9 | Motor cruiser | Ashore | Strong doubt | Harbour walk | 15 Mar 2026 | -41.198575, -22.598294 |
| #10 | Runabout | Ashore | Confirmed | Harbour walk | 15 Mar 2026 | -41.198817, -22.597586 |
| #11 | Sailing yacht | Sunk | Confirmed | Harbour walk | 16 Mar 2026 | -41.199625, -22.603573 |
| #12 | Sailing yacht | Ashore | Almost sure | Harbour walk | 16 Mar 2026 | -41.200690, -22.602156 |
| #13 | Motor cruiser | Ashore | Confirmed | Beach walk | 15 Mar 2026 | -41.202143, -22.601427 |
| #14 | Shrimp boat | Capsized | Confirmed | Drone flight | 16 Mar 2026 | -41.199948, -22.604216 |
| #15 | Sailing yacht | Ashore | Almost sure | Drone flight | 16 Mar 2026 | -41.199786, -22.602285 |
| #16 | Runabout | Ashore | Strong doubt | Drone flight | 16 Mar 2026 | -41.198462, -22.597457 |
:::
::::

## Register

| # | Type | Status | Grade | Seen in | First seen |
| --- | --- | --- | --- | --- | --- |
| #1 | Motor cruiser | Ashore | Confirmed | Marina survey | 15 Mar 2026 |
| #2 | Sailing yacht | Ashore | Confirmed | Marina survey | 15 Mar 2026 |
| #3 | Sailing yacht | Ashore | Almost sure | Marina survey | 15 Mar 2026 |
| #4 | Sailing yacht | Damaged | Confirmed | Marina survey | 15 Mar 2026 |
| #5 | Motor cruiser | Ashore | Almost sure | Marina survey | 15 Mar 2026 |
| #6 | Motor cruiser | Ashore | Confirmed | Marina survey | 15 Mar 2026 |
| #7 | Sailing yacht | Damaged | Confirmed | Marina survey | 15 Mar 2026 |
| #8 | Sport fisher | Ashore | Confirmed | Harbour walk | 15 Mar 2026 |
| #9 | Motor cruiser | Ashore | Strong doubt | Harbour walk | 15 Mar 2026 |
| #10 | Runabout | Ashore | Confirmed | Harbour walk | 15 Mar 2026 |
| #11 | Sailing yacht | Sunk | Confirmed | Harbour walk | 16 Mar 2026 |
| #12 | Sailing yacht | Ashore | Almost sure | Harbour walk | 16 Mar 2026 |
| #13 | Motor cruiser | Ashore | Confirmed | Beach walk | 15 Mar 2026 |
| #14 | Shrimp boat | Capsized | Confirmed | Drone flight | 16 Mar 2026 |
| #15 | Sailing yacht | Ashore | Almost sure | Drone flight | 16 Mar 2026 |
| #16 | Runabout | Ashore | Strong doubt | Drone flight | 16 Mar 2026 |
{search=always fold=20 first-column stripes colour="Grade" density=compact caption="Every boat the pictures show, once" source="Marina survey, harbour and beach walks, drone flight"}

One row per boat. The grade says how sure its type is, not how badly it was hit.

## By type

::: chart
kind: stacked bars
title: At least 16 boats, by type and grade
count: rows
by: Type
colour by: Grade
order: Confirmed, Almost sure, Strong doubt
from: sheet:e_1c3e0b3f71
source: the boat register
| Type | Grade |
| --- | --- |
| Motor cruiser | Confirmed |
| Sailing yacht | Confirmed |
| Sailing yacht | Almost sure |
| Sailing yacht | Confirmed |
| Motor cruiser | Almost sure |
| Motor cruiser | Confirmed |
| Sailing yacht | Confirmed |
| Sport fisher | Confirmed |
| Motor cruiser | Strong doubt |
| Runabout | Confirmed |
| Sailing yacht | Confirmed |
| Sailing yacht | Almost sure |
| Motor cruiser | Confirmed |
| Shrimp boat | Confirmed |
| Sailing yacht | Almost sure |
| Runabout | Strong doubt |
:::

## Every boat, one frame each

::: chart
kind: pictures
title: At least 16 boats, one frame each, by what became of them
by: Status
colour by: Grade
order: Confirmed, Almost sure, Strong doubt
picture: Picture
label: #
words: Type
shape: 3:2
source: Illustrations: FEMA, U.S. Coast Guard and U.S. Fish and Wildlife Service photos from Texas, Mississippi, Louisiana, Florida and North Carolina, 2004 to 2011, public domain; the boats, places and dates of this example are invented
| Picture | # | Type | Status | Grade |
| --- | --- | --- | --- | --- |
| [[media:e_7eb9083035|#1]] | #1 | Motor cruiser | Ashore | Confirmed |
| [[media:e_372ec89bff|#2]] | #2 | Sailing yacht | Ashore | Confirmed |
| [[media:e_d5fce7f284|#3]] | #3 | Sailing yacht | Ashore | Almost sure |
| [[media:e_384bd46c77|#4]] | #4 | Sailing yacht | Damaged | Confirmed |
| [[media:e_262afa205f|#5]] | #5 | Motor cruiser | Ashore | Almost sure |
| [[media:e_a022f72f6a|#6]] | #6 | Motor cruiser | Ashore | Confirmed |
| [[media:e_597f3b666e|#7]] | #7 | Sailing yacht | Damaged | Confirmed |
| [[media:e_62f0e1c819|#8]] | #8 | Sport fisher | Ashore | Confirmed |
| [[media:e_e546770757|#9]] | #9 | Motor cruiser | Ashore | Strong doubt |
| [[media:e_2bcc6c0019|#10]] | #10 | Runabout | Ashore | Confirmed |
| [[media:e_1ba66be3df|#11]] | #11 | Sailing yacht | Sunk | Confirmed |
| [[media:e_2f8d31a7af|#12]] | #12 | Sailing yacht | Ashore | Almost sure |
| [[media:e_ac822af464|#13]] | #13 | Motor cruiser | Ashore | Confirmed |
| [[media:e_7a3592a145|#14]] | #14 | Shrimp boat | Capsized | Confirmed |
| [[media:e_b6a707edbb|#15]] | #15 | Sailing yacht | Ashore | Almost sure |
| [[media:e_55362bba70|#16]] | #16 | Runabout | Ashore | Strong doubt |
:::

## Where they lie

::: map
title: Where each boat lies
layer: Boats lost
ground: e_d346bb84ba
timeline: off
north: on
:::

The register is a sheet of the case with a column of coordinates, so the map takes it as a layer coloured by grade, and follows the sheet when it changes. The ground under it is a real aerial photograph of another coast, used as an illustration, as its credit line says.

> [!limits] Boats sunk out of sight in the canal, and those the pictures saw only from far off, are not counted. The true number is higher.
