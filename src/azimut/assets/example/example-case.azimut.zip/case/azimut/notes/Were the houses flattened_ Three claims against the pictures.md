> [!note] Fictional example. Saltmere, its storm of 14 and 15 March 2026 and every account quoted here are invented, to show what a note can hold. The photographs are real public-domain pictures of other storms and places, used as illustrations: each caption says where and when it was really taken.

> [!warning] Two of the three claims are false and the third overstates: the houses stand, the launch is ashore, and at least 16 boats were lost, not fifty.

## The claims

| # | Claim | Made by | Day | Verdict |
| --- | --- | --- | --- | --- |
| 1 | "Every house at the west end has been flattened" | [[entity:e_f8ccbd3518|@saltmere_breaking]] | 15 Mar 2026 | False |
| 2 | "The island launch sank in the harbour" | [[entity:e_f8ccbd3518|@saltmere_breaking]] | 15 Mar 2026 | False |
| 3 | "Fifty boats destroyed at Saltmere" | [[entity:e_f8ccbd3518|@saltmere_breaking]] | 16 Mar 2026 | Misleading |
{search=always colour="Verdict"}

## Claims and pictures, day by day

::: chart
kind: timeline
title: Each claim, then what the pictures show
colour by: Kind
labels: short
source: posts of 15 and 16 March and the proofs of this case
| When | What happened | Kind |
| --- | --- | --- |
| 15 Mar 2026 | "Every house at the west end has been flattened" | Claim |
| 15 Mar 2026 | The old pier lost its end, the houses stand | Geolocated |
| 15 Mar 2026 | "The island launch sank in the harbour" | Claim |
| 15 Mar 2026 | The launch lies upright on the beach | Geolocated |
| 16 Mar 2026 | "Fifty boats destroyed at Saltmere" | Claim |
| 16 Mar 2026 | The register counts at least 16 | Geolocated |
:::

## How the first claim spread

```mermaid
flowchart LR
  n1["@saltmere_breaking: every house is flattened"]
  n2["Reposted, no picture"]
  n3["Roofs torn, walls standing"]
  n4("The houses stand")
  n1 --> n2
  n2 -.->|"the pictures"| n3
  n3 --> n4
  classDef c1 fill:#f8e5d6,stroke:#d55e00,color:#202124
  classDef c2 fill:#d6efe9,stroke:#009e73,color:#202124
  class n1,n2 c1
  class n3,n4 c2
  %% legend c1: Claim
  %% legend c2: What the pictures show
```

## Claim 1: the houses

> "Every house at the west end has been flattened." ([[entity:e_5ecc113fb6|@saltmere_breaking, 15 Mar]])

The post came with no picture. Pictures of the west end taken the same morning show the houses standing behind the sand the sea left, roofs torn and patched, walls whole ([[entity:e_ed0870fe29|proof]]). What the sea did take was the end of the old pier, 600 m to the east ([[entity:e_e542cb0bd2|proof]]).

[[media:e_ed0870fe29|The houses at the west end stand]]{width=75% caption="A house at the west end on 15 March. Illustration: FEMA photo by Mark Wolfe, Pensacola Beach, Florida, 15 October 2004, public domain; the scene and dates of this example are invented."}

[[media:e_e542cb0bd2|The old pier lost its end]]{width=75% caption="The old pier on 15 March. Illustration: FEMA photo by Marvin Nauman, Grand Isle, Louisiana, 1 November 2005, public domain; the scene and dates of this example are invented."}

> [!warning] False. The houses stand; their roofs are torn.

## Claim 2: the launch

> "The island launch sank in the harbour." ([[entity:e_7b8714f6d3|@saltmere_breaking, 15 Mar]])

[[media:e_620e8481e1|The launch is ashore, not sunk]]{width=75% caption="The launch on the beach on 15 March. Illustration: FEMA photo by Jocelyn Augustino, Pensacola Beach, Florida, 16 July 2005, public domain; the scene and dates of this example are invented."}

> [!warning] False. The launch lies upright on the beach west of the old pier, above the tide line.

## Claim 3: fifty boats

> "Fifty boats destroyed at Saltmere." ([[entity:e_9c85a96400|@saltmere_breaking, 16 Mar]])

The register counts at least 16 boats lost or damaged, 2 of them sunk ([[entity:e_fe2b2bf845|the register]]). Fifty is more than the marina held.

> [!unverified] Misleading. At least 16 boats, of which 11 were carried ashore and 2 sank.

## Corrections

17 March 2026: the first edition counted at least 15 boats. The drone flight of 16 March found a sixteenth in the salt marsh, and the count now reads at least 16.
